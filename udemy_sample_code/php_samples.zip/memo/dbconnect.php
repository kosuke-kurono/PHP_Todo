<?php
$db = new mysqli('localhost:8889', 'root', 'root', 'mydb');
?>