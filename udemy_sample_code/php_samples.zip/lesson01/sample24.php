<?php
header('Location: https://tomosta.jp');
exit();
?>