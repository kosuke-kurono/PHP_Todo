<?php
/* 税込金額を返す */
function intax($value) {
    return ceil($value * 1.1);
}
?>