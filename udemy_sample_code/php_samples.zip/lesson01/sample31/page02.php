<?php
require('intax.php');

echo intax(2000);