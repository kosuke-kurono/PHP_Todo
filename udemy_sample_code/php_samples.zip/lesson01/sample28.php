<?php
$random = rand(0, 1);
if ($random === 0) {
    echo '当たりです';
} else {
    echo 'ハズレです';
}
?>