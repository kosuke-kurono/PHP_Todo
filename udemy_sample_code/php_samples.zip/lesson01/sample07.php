<?php
$i = 1; // 初期化
while ($i < 366): // 繰り返し条件
    echo $i . '日<br>';
    $i = $i + 1; // 更新
endwhile;
?>