<?php
date_default_timezone_set('Asia/Tokyo');
echo '現在は、', date('G時 i分 s秒'), 'です';