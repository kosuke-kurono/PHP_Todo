<?php
for ($i=1; $i<366; $i++):
    echo $i . '<br>';
endfor;
?>