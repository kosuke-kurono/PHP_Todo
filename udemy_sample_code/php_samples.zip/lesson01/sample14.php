<?php
$date = sprintf('%04d.%02d.%02d', 123, 1, 2);
echo $date;
?>